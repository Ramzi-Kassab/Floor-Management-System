from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import transaction
# from .models import PurchaseReceiptItem, StockLedger  # uncomment when you wire these models

# @receiver(post_save, sender=PurchaseReceiptItem)
# def create_stock_ledger_on_receipt(sender, instance, created, **kwargs):
#     if not created: return
#     transaction.on_commit(lambda: StockLedger.objects.create(
#         item=instance.item, wh=instance.wh, loc=instance.loc,
#         qty_in=instance.qty, qty_out=0, voucher_type='PurchaseReceipt',
#         voucher_id=instance.pk, remarks=f"Auto from PR item {instance.pk}",
#     ))
