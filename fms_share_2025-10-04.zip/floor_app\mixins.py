import uuid
from django.db import models
from django.utils import timezone


# ---------- Soft delete ----------
class SoftDeleteQuerySet(models.QuerySet):
    def alive(self): return self.filter(is_deleted=False)
    def deleted(self): return self.filter(is_deleted=True)

class SoftDeleteManager(models.Manager):
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db).alive()

class AllObjectsManager(models.Manager):
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db)

class SoftDeleteMixin(models.Model):
    is_deleted = models.BooleanField(default=False, db_index=True, editable=False)
    deleted_at = models.DateTimeField(null=True, blank=True, editable=False)

    # Default: only alive records
    objects = SoftDeleteManager()
    # Opt-in: include deleted as well
    all_objects = AllObjectsManager()

    class Meta:
        abstract = True

    def delete(self, using=None, keep_parents=False):
        if not self.is_deleted:
            self.is_deleted = True
            self.deleted_at = timezone.now()
            self.save(update_fields=['is_deleted', 'deleted_at'])

    def restore(self):
        if self.is_deleted:
            self.is_deleted = False
            self.deleted_at = None
            self.save(update_fields=['is_deleted', 'deleted_at'])


# ---------- Public ID ----------
class PublicIdMixin(models.Model):
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    class Meta:
        abstract = True


# ---------- Document reference ----------
class DocumentReferenceMixin(models.Model):
    """Mixin for models that reference other documents"""
    ref_doctype = models.CharField(max_length=32, blank=True, db_index=True)
    ref_id = models.BigIntegerField(null=True, blank=True, db_index=True)

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=['ref_doctype', 'ref_id'], name='ix_%(class)s_ref'),
        ]


# ---------- Party type & reference ----------
class PartyType(models.TextChoices):
    CUSTOMER = 'Customer', 'Customer'
    SUPPLIER = 'Supplier', 'Supplier'

class PartyReferenceMixin(models.Model):
    """Mixin for models that reference Customer or Supplier"""
    party_type = models.CharField(max_length=16, choices=PartyType.choices, db_index=True)
    party_id = models.BigIntegerField()

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=['party_type', 'party_id'], name='ix_%(class)s_party'),
        ]
        constraints = [
            models.CheckConstraint(check=models.Q(party_id__gt=0), name='ck_%(class)s_party_id_pos'),
        ]


# ---------- Posting ----------
class PostingMixin(models.Model):
    """Mixin for documents with posting timestamp"""
    posting_ts = models.DateTimeField(db_index=True, default=timezone.now)

    class Meta:
        abstract = True
        ordering = ['-posting_ts']
